<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" action="<?php echo e(route('general.setting.update')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><?php echo e(__('General Settings')); ?></h4>
                                <p class="card-category"><?php echo e(__('Basic Settings')); ?></p>
                            </div>
                            <div class="card-body ">
                                <?php if(session('status')): ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php
                                    $data=\App\Models\GenaralSettings::all()->first();
                                 ?>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label"><?php echo e(__('Phone')); ?></label>
                                    <div class="col-sm-7">
                                        <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" id="input-name" type="text" placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e(old('Phone', $data->site_phone)); ?>" required="true" aria-required="true"/>
                                            <?php if($errors->has('phone')): ?>
                                                <span id="name-error" class="error text-danger" for="input-name"><?php echo e($errors->first('phone')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label"><?php echo e(__('Email')); ?></label>
                                    <div class="col-sm-7">
                                        <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="input-email" type="email" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email', $data->site_mail)); ?>" required />
                                            <?php if($errors->has('email')): ?>
                                                <span id="email-error" class="error text-danger" for="input-email"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                        <label class="col-sm-2 col-form-label"><?php echo e(__('Logo')); ?></label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <input type="text" onclick="this.type ='file'" class="form-control" >
                                            </div>
                                        </div>
                                    </div>
                                <div class="row">
                                        <label class="col-sm-2 col-form-label"><?php echo e(__('Slogan')); ?></label>
                                        <div class="col-sm-7">
                                            <div class="form-group<?php echo e($errors->has('site_slogan') ? ' has-danger' : ''); ?>">
                                                <input class="form-control<?php echo e($errors->has('site_slogan') ? ' is-invalid' : ''); ?>" name="site_slogan" id="input-site_slogan" type="text" placeholder="<?php echo e(__('Slogan')); ?>" value="<?php echo e(old('site_slogan', $data->site_slogan)); ?>" required />
                                                <?php if($errors->has('site_slogan')): ?>
                                                    <span id="site_slogan-error" class="error text-danger" for="input-site_slogan"><?php echo e($errors->first('site_slogan')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="card-footer ml-auto mr-auto">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'settings', 'titlePage' => __('Settings')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal\Deltastar\resources\views/backend/generalsetting/index.blade.php ENDPATH**/ ?>