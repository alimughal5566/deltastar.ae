<?php $__env->startSection('content'); ?>
<div class="container" style="height: auto;">
  <div class="row justify-content-center">
      <div class="col-lg-7 col-md-8">
          <div class="card card-login card-hidden mb-3">
            <div class="card-header card-header-primary text-center">
              <p class="card-title"><strong><?php echo e(__('Verify Your Email Address')); ?></strong></p>
            </div>
            <div class="card-body">
              <p class="card-description text-center"></p>
              <p>
                <?php if(session('resent')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                    </div>
                <?php endif; ?>
                
                <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                
                <?php if(Route::has('verification.resend')): ?>
                    <?php echo e(__('If you did not receive the email')); ?>,  
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('click here to request another')); ?></button>.
                    </form>
                <?php endif; ?>
              </p>
            </div>
          </div>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'off-canvas-sidebar', 'activePage' => 'home', 'title' => __('Material Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal\Deltastar\resources\views\auth\verify.blade.php ENDPATH**/ ?>