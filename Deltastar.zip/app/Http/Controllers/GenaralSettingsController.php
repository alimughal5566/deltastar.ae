<?php

namespace App\Http\Controllers;

use App\Models\GenaralSettings;
use Illuminate\Http\Request;

class GenaralSettingsController extends Controller
{
    public function index(){
        return view('backend.generalsetting.index');
    }
    public function update(Request $request){
        $data=GenaralSettings::where('id',1)->update([
            'site_phone'=>$request['phone'],
            'site_mail'=>$request['email'],
            'site_slogan'=>$request['site_slogan']
        ]);
return redirect()->back()->with('status','updated successfully');
    }
}
