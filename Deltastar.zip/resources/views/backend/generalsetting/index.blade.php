@extends('layouts.app', ['activePage' => 'settings', 'titlePage' => __('Settings')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" action="{{ route('general.setting.update') }}" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
                        @csrf

                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title">{{ __('General Settings') }}</h4>
                                <p class="card-category">{{ __('Basic Settings') }}</p>
                            </div>
                            <div class="card-body ">
                                @if (session('status'))
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <span>{{ session('status') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                                @php
                                    $data=\App\Models\GenaralSettings::all()->first();
                                 @endphp
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Phone') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group{{ $errors->has('phone') ? ' has-danger' : '' }}">
                                            <input class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}" name="phone" id="input-name" type="text" placeholder="{{ __('Phone') }}" value="{{ old('Phone', $data->site_phone) }}" required="true" aria-required="true"/>
                                            @if ($errors->has('phone'))
                                                <span id="name-error" class="error text-danger" for="input-name">{{ $errors->first('phone') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">{{ __('Email') }}</label>
                                    <div class="col-sm-7">
                                        <div class="form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
                                            <input class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" id="input-email" type="email" placeholder="{{ __('Email') }}" value="{{ old('email', $data->site_mail) }}" required />
                                            @if ($errors->has('email'))
                                                <span id="email-error" class="error text-danger" for="input-email">{{ $errors->first('email') }}</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Logo') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <input type="text" onclick="this.type ='file'" class="form-control" >
                                            </div>
                                        </div>
                                    </div>
                                <div class="row">
                                        <label class="col-sm-2 col-form-label">{{ __('Slogan') }}</label>
                                        <div class="col-sm-7">
                                            <div class="form-group{{ $errors->has('site_slogan') ? ' has-danger' : '' }}">
                                                <input class="form-control{{ $errors->has('site_slogan') ? ' is-invalid' : '' }}" name="site_slogan" id="input-site_slogan" type="text" placeholder="{{ __('Slogan') }}" value="{{ old('site_slogan', $data->site_slogan) }}" required />
                                                @if ($errors->has('site_slogan'))
                                                    <span id="site_slogan-error" class="error text-danger" for="input-site_slogan">{{ $errors->first('site_slogan') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="card-footer ml-auto mr-auto">
                                <button type="submit" class="btn btn-primary">{{ __('Update') }}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
